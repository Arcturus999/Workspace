CVBANK
======

Java web application to store candidates resumes. It uses JEST api and Elasticsearch